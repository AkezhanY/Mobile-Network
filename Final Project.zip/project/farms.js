<script>
  // Mobile Menu
  let menu = document.querySelector('#menu-icon');
  let navbar = document.querySelector('.navbar');

  menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('active');
  }

  window.onscroll = () => {
    menu.classList.remove('bx-x');
    navbar.classList.remove('active');
  }

  

  sr.reveal('.text', { delay: 200, origin: 'top' });
  sr.reveal('.heading', { delay: 300, origin: 'top' });
  sr.reveal('.stats-container .box', { delay: 200, origin: 'bottom', interval: 200 });
  sr.reveal('.windows-container .box', { delay: 200, origin: 'bottom', interval: 200 });
  sr.reveal('.services-container .box', { delay: 200, origin: 'bottom', interval: 200 });
  sr.reveal('.newsletter .box', { delay: 300, origin: 'bottom' });
</script>